package JAVA;

public class Example {

	public static void main(String[] args) {
		int a=0,b,c;
		for(;a<3;a++){
	
	System.out.print(" " );
	b=0;
			for(;b<3-a;b++){
				System.out.print(" " );
		}
c=0;

			for(;c<=a;c++){
				System.out.print("*");
			
			}
	
			System.out.println( );	
		}
		

	}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
}
