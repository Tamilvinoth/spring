package JAVA;

public class Loopexample {

	public static void main(String[] args) {
		int a=0,b=1,c=0;
		for(;a<3;a++){
			c=3+b;
			for(;b<c;b++){
				System.out.print(c);
				
			}
			System.out.println( );	
		}
		

	}

}
