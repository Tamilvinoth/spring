package JAVA;

public class Myclass {

	public static void main(String[] args) {
    int a=0,b,c;
    for(;a<3;a++){
    	
    b=0;
    for(;b<=a;b++){
    	System.out.print("* ");
    }
    System.out.println( );
    }

	}

}
