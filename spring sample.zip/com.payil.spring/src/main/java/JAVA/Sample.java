package JAVA;

public class Sample {

	public static void main(String[] args) {



	}

}
