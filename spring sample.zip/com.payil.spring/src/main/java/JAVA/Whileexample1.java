package JAVA;

public class Whileexample1 {

	public static void main(String[] args) {
    int a=1,b,c=1;
    while (a<=3){
   

   
   b=1;
    	while (b<=a){
    		System.out.print(c++);
    		b++;
    		
    	}
    	a++;
    	System.out.println( );
    }

	}

}
